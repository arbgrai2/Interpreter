#include "Sequence.h"

Sequence::Sequence() : Type()
{
}

Sequence::~Sequence() = default;
