
#pragma once

#include "Type.h"

class Sequence : public Type
{
public:
	Sequence();
	virtual ~Sequence();

};